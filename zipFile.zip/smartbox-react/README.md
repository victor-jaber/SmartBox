# SmartBox (React)

Conversão do `index.html` para um projeto React (Vite).

## Rodar localmente
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

> Observação: Mantive o Tailwind via CDN (igual o HTML original) para ficar plug-and-play.
